import { useMemo, useState, useRef, useEffect } from "react"
import { useNavigate } from "react-router-dom"
import { PageHeader } from "@/components/ui/PageHeader"
import { Card } from "@/components/ui/Card"
import { Button } from "@/components/ui/Button"
import { Avatar } from "@/components/ui/Avatar"
import { Calendar, Search } from "lucide-react"
import { tasks, getTask, Task } from "@/data/tasks"
import { downloadCsv } from '@/lib/utils'
import TaskModal from "@/components/ui/TaskModal"
import { toast } from "@/components/ui/Toast"
import RowActionsPopover from "@/components/ui/RowActionsPopover"
import { employees } from "@/data/employees"

export default function AdminTasks() {
  const navigate = useNavigate()
  const [q, setQ] = useState('')
  const [debouncedQ, setDebouncedQ] = useState(q)
  const [filterStatus, setFilterStatus] = useState('')
  const [filterPriority, setFilterPriority] = useState('')
  const [page, setPage] = useState(1)
  const pageSize = 6

  const [selectedTask, setSelectedTask] = useState<Task | null>(null)
  const [modalOpen, setModalOpen] = useState(false)
  const [popoverOpen, setPopoverOpen] = useState(false)
  const popoverAnchor = useRef<HTMLButtonElement | null>(null)

  function openTask(t: Task) {
    setSelectedTask(t)
    setModalOpen(true)
  }

  function saveTask(updated: Task) {
    const idx = tasks.findIndex((x) => x.id === updated.id)
    if (idx !== -1) tasks[idx] = updated
  }

  function deleteTask(id: string) {
    const idx = tasks.findIndex((x) => x.id === id)
    if (idx !== -1) tasks.splice(idx, 1)
  }

  // listen for external task changes
  useEffect(() => {
    function onChanged() { /* trigger rerender */ setDebouncedQ((s) => s + '') }
    window.addEventListener('tasks:changed', onChanged as any)
    return () => window.removeEventListener('tasks:changed', onChanged as any)
  }, [])

  // debounce q -> debouncedQ
  useEffect(() => {
    const id = window.setTimeout(() => setDebouncedQ(q), 250)
    return () => window.clearTimeout(id)
  }, [q])

  const filtered = useMemo(() => {
    const qq = (debouncedQ || '').toLowerCase()
    return (tasks || []).filter(t => {
      if (qq) {
        const hay = `${t?.name} ${t?.client} ${t?.id} ${t?.employee || ''} ${t?.status || ''} ${t?.priority || ''}`.toLowerCase()
        if (!hay.includes(qq)) return false
      }
      if (filterStatus && t?.status !== filterStatus) return false
      if (filterPriority && t?.priority !== filterPriority) return false
      return true
    })
  }, [debouncedQ, filterStatus, filterPriority])

  const totalPages = Math.max(1, Math.ceil((filtered || []).length / pageSize))
  const pageItems = (filtered || []).slice((page-1)*pageSize, page*pageSize)
  return (
    <div>
      <PageHeader title="Operational Task Board" subtitle="Manage GST filings and MCA compliance workflows" />

      <div className="mt-6 px-6">
        <div className="flex items-center justify-end mb-6">
          <div className="flex items-center gap-3 mr-auto">
            <div className="relative">
              <Search className="absolute left-3 top-3 text-ink-muted" />
              <input value={q} onChange={(e) => { setQ(e.target.value); setPage(1) }} placeholder="Search tasks, clients, or filings..." className="pl-10 pr-3 h-10 rounded-lg border border-line bg-white w-96" />
            </div>
            <select value={filterStatus} onChange={(e) => { setFilterStatus(e.target.value); setPage(1) }} className="h-10 rounded-lg border border-line bg-surface px-3 text-sm">
              <option value="">All Statuses</option>
              <option>Not Started</option>
              <option>In Progress</option>
              <option>Waiting For Client</option>
              <option>Completed</option>
              <option>Overdue</option>
            </select>
            <select value={filterPriority} onChange={(e) => { setFilterPriority(e.target.value); setPage(1) }} className="h-10 rounded-lg border border-line bg-surface px-3 text-sm">
              <option value="">All Priorities</option>
              <option>Low</option>
              <option>Medium</option>
              <option>High</option>
              <option>Critical</option>
            </select>
            <Button variant="outline" size="sm" onClick={() => { const rows = (tasks || []).map(t => ({ id: t.id, name: t.name, client: t.client, status: t.status })); downloadCsv(rows, 'tasks.csv'); toast({ type: 'success', message: 'Exported tasks' }) }}>Export</Button>
          </div>
          <Button variant="primary" className="px-6 py-3 text-sm" onClick={() => navigate('/tasks/create')}>+ Create Task</Button>
        </div>

        {/* Top Not Started container */}
        <div className="rounded-xl bg-surface p-6 mb-8 border border-line">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <span className="h-2 w-2 rounded-full bg-ink-muted inline-block"></span>
              <div className="text-sm font-semibold uppercase text-ink-muted">NOT STARTED</div>
              <div className="ml-2 text-xs bg-white px-2 py-1 rounded text-ink">{(tasks || []).filter(t => t?.status === 'Not Started').length}</div>
            </div>
            <div className="text-sm text-ink-muted">...</div>
          </div>

          <div className="flex items-start gap-6">
            <div className="flex-1 grid grid-cols-2 gap-6">
                {[0, 1].map((idx) => {
                  const t = (tasks || []).filter(tt => tt?.status === 'Not Started')[idx]
                if (t) {
                  return (
                      <Card key={t.id} className="p-6 cursor-pointer" onClick={() => openTask(t)}>
                          <div className="flex items-start justify-between">
                            <div>
                              <div className="inline-block px-2 py-1 rounded text-xs font-semibold bg-amber/10 text-amber-700">GST GSTR-1</div>
                              <div className="text-lg font-bold text-ink mt-3">{t.name}</div>
                              <div className="text-sm text-ink-muted mt-2">Client: {t.client}</div>
                            </div>
                            <div className="text-sm text-ink-muted text-right">
                              <div className="text-xs text-amber-700 font-semibold">{t.priority}</div>
                              <div className="mt-6 text-sm"><Calendar className="inline-block mr-1" style={{ verticalAlign: 'middle' }} />{t.dueDate}</div>
                            </div>
                          </div>
                          <div className="mt-6 flex items-end">
                            <div className="flex items-center gap-2">
                                <Avatar name={t.employee || t.client} size={28} />
                                <div className="ml-auto relative">
                                  <button ref={(el) => { popoverAnchor.current = el }} onClick={() => setPopoverOpen((s) => !s)} className="h-8 w-8 rounded-full bg-surface flex items-center justify-center">⋮</button>
                                  <RowActionsPopover open={popoverOpen} anchorRef={popoverAnchor} onClose={() => setPopoverOpen(false)} onEdit={() => { openTask(t); setPopoverOpen(false) }} onView={() => { openTask(t); setPopoverOpen(false) }} />
                                </div>
                            </div>
                          </div>
                        </Card>
                  )
                }
                return (
                  <div key={idx} className="border border-line bg-white rounded-lg p-6 h-40"></div>
                )
              })}
            </div>

            <div className="w-64 flex-shrink-0">
              <div className="h-full flex items-center justify-center border-2 border-dashed border-line rounded-lg bg-white/30 text-ink-muted">+ Add Task</div>
            </div>
          </div>
        </div>

        {/* Lower columns */}
        <div className="grid grid-cols-3 gap-6">
          <div>
            <div className="text-sm font-semibold uppercase text-ink-muted mb-3 flex items-center justify-between"><span>IN PROGRESS</span><span className="text-xs bg-white px-2 py-1 rounded text-ink">{(tasks || []).filter(t => t?.status === 'In Progress').length}</span></div>
            <div className="space-y-4">
              {(tasks || []).filter(t => t?.status === 'In Progress').map(t => (
                <Card key={t.id} className="p-4 cursor-pointer" onClick={() => openTask(t)}>
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="text-sm font-bold text-ink">{t.name}</div>
                      <div className="text-xs text-ink-muted mt-1">Client: {t.client}</div>
                    </div>
                    <div className="text-xs text-ink-muted text-right">
                      <div className="text-xs font-semibold text-amber-700">{t.priority}</div>
                      <div className="mt-2 text-xs"><Calendar className="inline-block mr-1" style={{ verticalAlign: 'middle' }} />{t.dueDate}</div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          <div>
            <div className="text-sm font-semibold uppercase text-ink-muted mb-3 flex items-center justify-between"><span>WAITING FOR CLIENT</span><span className="text-xs bg-white px-2 py-1 rounded text-ink">{(tasks || []).filter(t => t?.status === 'Waiting For Client').length}</span></div>
            <div className="space-y-4">
              {(tasks || []).filter(t => t?.status === 'Waiting For Client').map(t => (
                <Card key={t.id} className="p-4 cursor-pointer" onClick={() => openTask(t)}>
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="text-sm font-bold text-ink">{t.name}</div>
                      <div className="text-xs text-ink-muted mt-1">Client: {t.client}</div>
                    </div>
                    <div className="text-xs text-ink-muted">{t.dueDate}</div>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          <div>
            <div className="text-sm font-semibold uppercase text-ink-muted mb-3 flex items-center justify-between"><span>REVIEW</span><span className="text-xs bg-white px-2 py-1 rounded text-ink">{(tasks || []).filter(t => t?.status === 'Review').length}</span></div>
            <div className="space-y-4">
              {(tasks || []).filter(t => t?.status === 'Review').map(t => (
                <Card key={t.id} className="p-4 cursor-pointer" onClick={() => openTask(t)}>
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="text-sm font-bold text-ink">{t.name}</div>
                      <div className="text-xs text-ink-muted mt-1">Client: {t.client}</div>
                    </div>
                    <div className="text-xs text-ink-muted">{t.dueDate}</div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
      <TaskModal task={selectedTask} open={modalOpen} onClose={() => setModalOpen(false)} onSave={(t) => { saveTask(t); setModalOpen(false) }} onDelete={(id) => { deleteTask(id); setModalOpen(false) }} />
    </div>
  )
}
