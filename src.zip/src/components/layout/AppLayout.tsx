import { Outlet } from "react-router-dom"
import { Sidebar, type NavItem } from "./Sidebar"
import { Topbar } from "./Topbar"

export function AppLayout({
  navItems,
  userName,
  userRole,
  searchPlaceholder,
}: {
  navItems: NavItem[]
  userName: string
  userRole: string
  searchPlaceholder?: string
}) {
  return (
    <div className="min-h-screen bg-canvas">
      <Sidebar title="Admin Console" subtitle="GST & MCA Operations" items={navItems} />
      <div style={{ paddingLeft: 'var(--sidebar-width)' }}>
        <Topbar userName={userName} userRole={userRole} searchPlaceholder={searchPlaceholder} />
        <main className="px-8 py-8">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
